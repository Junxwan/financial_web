<?php

namespace App\Services;

use App\Repositories\PriceRepository;
use App\Repositories\TagRepository;
use Illuminate\Support\Arr;

class Industry
{
    /**
     * @var PriceRepository
     */
    private PriceRepository $price;

    /**
     * @var TagRepository
     */
    private TagRepository $tag;

    /**
     * Industry constructor.
     *
     * @param PriceRepository $price
     * @param TagRepository $tag
     */
    public function __construct(PriceRepository $price, TagRepository $tag)
    {
        $this->price = $price;
        $this->tag = $tag;
    }

    /**
     * @param array $select
     *
     * @return \Illuminate\Database\Eloquent\Builder[]|\Illuminate\Database\Eloquent\Collection|\Illuminate\Support\Collection
     */
    public function list(array $select)
    {
        $tag = $this->tag->allByShowPrice();

        $price = $this->price->getByTag($tag->pluck('id')->toArray());

        $data = $tag->map(function ($item) use ($price) {
            $item->increase = 0;
            $item->volume = 0;

            $increase = [];
            $value = [];
            foreach ($price as $v) {
                if (in_array($item->id, $v->tag_id)) {
                    $increase[] = $v->increase;
                    $value[] = $v->value;
                }
            }

            if (count($increase) > 0) {
                $item->increase = round(array_sum($increase) / count($increase), 2);
                $item->volume = array_sum($value);
            }

            return $item;
        })->sortByDesc('increase');

        return [
            'data' => $data,
            'total' => $data->count(),
        ];
    }
}
